export interface ClinicModel {
	_id: string
	name: string
}

import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ButtonModule } from 'primeng/button'
import { InputTextModule } from 'primeng/inputtext'
import { PasswordModule } from 'primeng/password'
import { CardModule } from 'primeng/card'

import { ReactiveFormsModule } from '@angular/forms'

const primeModules = [
	CommonModule,
	CardModule,
	ButtonModule,
	InputTextModule,
	PasswordModule,
]

@NgModule({
	declarations: [],
	imports: [ReactiveFormsModule, ...primeModules],
	exports: [ReactiveFormsModule, ...primeModules]
})
export class SharedModule { }
